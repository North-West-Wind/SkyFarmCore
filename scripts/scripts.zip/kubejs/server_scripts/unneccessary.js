onEvent('recipes', event => {
  event.remove({ output: 'cyclic:void_charm' });
  event.remove({ output: "cyclic:shears_flint", type: "minecraft:crafting_shaped" });
});

onEvent("player.inventory.changed", event => {
  if (event.getEntity().getOpenInventory().getClass().getName() == "net.minecraft.inventory.container.PlayerContainer") {
    // Get held item
    var heldItem = event.getItem()
    let ingr = Ingredient.of("mysticalworld:silkworm_egg")
    if (ingr.test(heldItem)) {
      let slot = event.getSlot()
      if (slot <= 5) slot += 36
      else if (slot == 45) slot = 40
      else if (slot >= 36) slot -= 36
      // Update item
      event.getEntity().inventory.set(slot, Item.of("minecraft:air", 0))
    }
  }
})

// Items on ground
onEvent("entity.spawned", event => {
  var entity = event.getEntity()
  if (!entity) return;
  if (entity.getType() == "minecraft:item") {
    var gItem = entity.getItem()
    let ingr = Ingredient.of("mysticalworld:silkworm_egg")
    if (ingr && gItem && ingr.test(gItem)) entity.setItem(Item.of("minecraft:air", 0))
  }
})