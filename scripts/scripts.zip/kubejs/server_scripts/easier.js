onEvent('recipes', event => {
    // Create
    event.remove({ type: 'minecraft:crafting_shaped', output: 'create:andesite_alloy' });
    event.shaped('8x create:andesite_alloy', [
        'AB',
        'BA'
    ], {
        A: '#forge:nuggets/iron',
        B: 'minecraft:andesite'
    });
    event.shaped('8x create:andesite_alloy', [
        'AB',
        'BA'
    ], {
        A: '#forge:nuggets/zinc',
        B: 'minecraft:andesite'
    });
    event.replaceInput({ type: 'minecraft:crafting_shapeless' }, 'create:brass_casing', 'create:andesite_casing');
    event.replaceInput({ type: 'minecraft:crafting_shaped' }, 'create:brass_casing', 'create:andesite_casing');

    event.replaceInput({ type: 'minecraft:crafting_shapeless' }, 'create:integrated_circuit', 'create:large_cogwheel');
    event.replaceInput({ type: 'minecraft:crafting_shaped' }, 'create:integrated_circuit', 'create:large_cogwheel');

    event.remove({ output: 'create:blaze_burner' });
    event.shaped('create:blaze_burner', [
        'III',
        'BLB',
        'BBB'
    ], {
        I: '#forge:plates/iron',
        B: 'minecraft:iron_bars',
        L: 'minecraft:lava_bucket'
    });

    // Tinker's Construct
    event.remove({ output: "tconstruct:grout", type: "minecraft:crafting_shapeless" });

    // Mekanism
    event.remove({ output: "mekanism:alloy_reinforced", type: "mekanism:metallurgic_infusing" });
    event.remove({ output: "mekanism:alloy_atomic", type: "mekanism:metallurgic_infusing" });

    event.recipes.mekanism.metallurgic_infusing('mekanism:alloy_reinforced', '#mekanism:alloys/infused', 'mekanism:diamond', 10);
    event.recipes.mekanism.metallurgic_infusing('mekanism:alloy_atomic', '#mekanism:alloys/reinforced', 'mekanism:refined_obsidian', 10);
});