events.listen('player.logged_in', function (event) {
    if (!event.hasGameStage('starting_items')) {
        event.addGameStage('starting_items')
        event.player.give('mysticalagriculture:dirt_seeds')
    }
})