onEvent('recipes', event => {
    event.replaceInput({ type: 'minecraft:crafting_shaped', output: "coffeespawner:coffee_machine" }, 'minecraft:cocoa_beans', '#forge:crops/coffeebean');
});