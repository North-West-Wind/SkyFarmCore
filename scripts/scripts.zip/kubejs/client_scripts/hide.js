onEvent('jei.hide.items', event => {
	event.hide('mysticalworld:silkworm_egg');
	event.hide('cyclic:shears_flint');
})